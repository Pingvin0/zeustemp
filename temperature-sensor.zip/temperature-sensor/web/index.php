<?php
require_once 'core.php';




?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include("head.html"); ?>
</head>
<body>

<form action="chart.php" method="POST">
Ettől:
<input name="from" type="date"><br>
Eddíg:
<input name="to" type="date">
<input type="submit">
</form>


</body>
</html>