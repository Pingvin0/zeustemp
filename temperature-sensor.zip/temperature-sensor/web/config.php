<?php

return [
    "DB_HOST" => "192.168.0.16",
    "DB_USER" => "zeus",
    "DB_PASS" => "exTs3wDlf9MAgVsT",
    "DB_NAME" => "zeus"
];
?>