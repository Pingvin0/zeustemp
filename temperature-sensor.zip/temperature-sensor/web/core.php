<?php
set_include_path(get_include_path() . PATH_SEPARATOR . "/var/www/zeus");

$cfg = include("config.php");

require_once 'inc/db.php';

?>